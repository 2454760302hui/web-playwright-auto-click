from web_clicker import WebClicker
import os
import sys

def main():
    try:
        url = input("请输入要测试的网址: ").strip()
        if not url:
            print("错误: URL不能为空")
            return
            
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
            
        print("\n正在初始化浏览器...")
        clicker = WebClicker('config/click_rules.yml')
        print("浏览器初始化成功")
        
        clicker.start(url)
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序运行出错: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n程序已结束")
        input("按回车键退出...")

if __name__ == "__main__":
    main() 