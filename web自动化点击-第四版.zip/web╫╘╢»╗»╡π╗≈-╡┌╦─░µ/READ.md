根目录下 执行 python main.py
