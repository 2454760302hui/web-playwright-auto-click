from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import *
import yaml
import time
import os
from datetime import datetime
import logging
import traceback
from openpyxl import Workbook
from openpyxl.drawing.image import Image
from PIL import Image as PILImage

# 确保配置目录存在
os.makedirs('config', exist_ok=True)
os.makedirs('screenshots', exist_ok=True)

# 在文件开头添加 __all__ 声明
__all__ = ['WebClicker']

class WebClicker:  # 确保类名与导入名称一致
    def __init__(self, config_path):
        try:
            # 初始化基本属性
            self.running = True
            self.visited_urls = set()
            self.clicked_elements = set()
            self.visited_elements = set()
            self.current_url = None  # 添加当前URL属性
            
            # 设置默认配置
            self.config = {
                'timeout': {
                    'page_load': 30,
                    'element_wait': 10,
                    'dynamic_wait': 3
                },
                'screenshot': {
                    'enabled': True,
                    'path': 'screenshots'
                },
                'click_behavior': {
                    'wait_time': 2,
                    'highlight': True,
                    'retry_count': 3
                }
            }
            
            # 初始化浏览器
            self.setup_browser()
            
            # 设置日志
            self.setup_logging()
            
            # 创建必要的目录
            os.makedirs('screenshots', exist_ok=True)
            os.makedirs('logs', exist_ok=True)
            
            # 初始化Excel工作簿
            self.workbook = Workbook()
            self.sheet = self.workbook.active
            self.setup_excel()
            
            # 创建结果目录
            self.result_dir = f"result_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            self.screenshots_dir = os.path.join(self.result_dir, "screenshots")
            os.makedirs(self.screenshots_dir, exist_ok=True)
            
        except Exception as e:
            print(f"初始化失败: {str(e)}")
            raise

    def setup_browser(self):
        """设置浏览器"""
        try:
            print("正在启动Chrome浏览器...")
            options = webdriver.ChromeOptions()
            options.add_argument('--start-maximized')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')
            options.add_experimental_option('excludeSwitches', ['enable-automation'])
            options.add_experimental_option('useAutomationExtension', False)
            
            self.driver = webdriver.Chrome(options=options)
            self.wait = WebDriverWait(self.driver, self.config['timeout']['page_load'])
            print("Chrome浏览器启动成功")
            
        except Exception as e:
            print(f"启动浏览器失败: {str(e)}")
            raise

    def setup_logging(self):
        """设置日志"""
        try:
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(levelname)s - %(message)s',
                handlers=[
                    logging.FileHandler('logs/crawler.log'),
                    logging.StreamHandler()
                ]
            )
            self.logger = logging.getLogger(__name__)
            
        except Exception as e:
            print(f"设置日志失败: {str(e)}")
            self.logger = logging.getLogger(__name__)

    def setup_excel(self):
        """设置Excel表头和格式"""
        try:
            # 设置表头
            headers = [
                '序号',
                '元素类型',
                '元素文本',
                '位置信息',
                '点击状态',
                '错误信息',
                '操作截图'
            ]
            
            # 写入表头
            for col, header in enumerate(headers, 1):
                cell = self.sheet.cell(row=1, column=col, value=header)
                
                # 设置表头格式
                from openpyxl.styles import Font, Alignment, PatternFill
                
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.fill = PatternFill(start_color="CCCCCC", end_color="CCCCCC", fill_type="solid")
            
            # 调整列宽
            column_widths = [10, 15, 30, 20, 15, 30, 50]
            for i, width in enumerate(column_widths, 1):
                self.sheet.column_dimensions[chr(64 + i)].width = width
                
            # 冻结首行
            self.sheet.freeze_panes = 'A2'
            
        except Exception as e:
            print(f"设置Excel格式失败: {str(e)}")

    def process_page(self, url, depth=0, parent_url=None, allowed_urls=None):
        """处理页面，包括子页面的递归处理"""
        try:
            # 检查是否在允许的URL列表中
            if allowed_urls is not None and url not in allowed_urls:
                print(f"跳过非指定页面: {url}")
                return
            
            if depth > 5:  # 限制递归深度
                print(f"达到最大递归深度 {depth}，停止处理")
                return
            
            if url in self.visited_urls:
                print(f"页面已访问过: {url}")
                return
            
            print(f"\n开始处理页面: {url} (深度: {depth})")
            
            # 访问页面
            self.driver.get(url)
            
            # 检查是否需要登录
            if self.check_login_required():
                print("\n检测到需要登录！")
                print("请在浏览器中完成登录操作...")
                
                # 等待用户登录，登录成功后立即继续
                if self.wait_for_login():
                    print("登录成功，继续处理页面")
                else:
                    print("登录等待超时，停止处理")
                    return
            
            self.visited_urls.add(url)
            self.current_url = url  # 更新当前URL
            
            # 等待页面加载
            self.wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            time.sleep(2)
            
            # 获取当前页面的可点击元素
            elements = self.get_clickable_elements()
            print(f"\n在页面 {url} 中找到 {len(elements)} 个可点击元素")
            
            # 处理每个元素
            for idx, element_data in enumerate(elements, 1):
                try:
                    element = element_data['element']
                    info = element_data['info']
                    position = element_data['position']
                    
                    # 准备记录数据
                    row_data = {
                        'index': idx,
                        'type': info['type'],
                        'text': info['text'],
                        'position': f"top={position['top']:.0f}, left={position['left']:.0f}",
                        'status': '',
                        'error': '',
                        'screenshot': ''
                    }
                    
                    print(f"\n处理元素 {idx}/{len(elements)}")
                    print(f"类型: {info['type']}")
                    print(f"文本: {info['text'][:50]}...")
                    
                    # 验证元素是否仍然存在
                    if not self.verify_element_exists(element):
                        continue
                    
                    # 滚动到元素位置
                    if not self.scroll_to_element(element):
                        continue
                    
                    # 高亮显示并截图
                    if self.safe_highlight_element(element):
                        screenshot_path = self.take_screenshot(f"before_click_{depth}_{idx}")
                        row_data['screenshot'] = screenshot_path
                    
                    # 记录当前状态
                    original_url = self.driver.current_url
                    original_handles = self.driver.window_handles
                    
                    # 尝试点击元素
                    if self.click_element(element):
                        print("点击成功")
                        row_data['status'] = '成功'
                        time.sleep(2)  # 等待页面变化
                        
                        # 处理新窗口
                        new_handles = [h for h in self.driver.window_handles if h not in original_handles]
                        if new_handles:
                            for handle in new_handles:
                                self.driver.switch_to.window(handle)
                                new_url = self.driver.current_url
                                if new_url not in self.visited_urls and (allowed_urls is None or new_url in allowed_urls):
                                    child_pages.add(new_url)
                                self.driver.close()
                            self.driver.switch_to.window(original_handles[0])
                        
                        # 检查URL变化
                        current_url = self.driver.current_url
                        if current_url != original_url:
                            if current_url not in self.visited_urls and (allowed_urls is None or current_url in allowed_urls):
                                child_pages.add(current_url)
                            # 返回原页面
                            self.driver.back()
                            time.sleep(2)
                    else:
                        print("点击失败")
                        row_data['status'] = '失败'
                        row_data['error'] = '点击操作未成功'
                    
                    # 写入Excel
                    self.write_to_excel(row_data)
                    
                except Exception as element_error:
                    print(f"处理元素时出错: {str(element_error)}")
                    continue
            
            # 处理所有子页面
            print(f"\n页面 {url} 处理完成，发现 {len(child_pages)} 个子页面")
            for child_url in child_pages:
                print(f"\n开始处理子页面: {child_url}")
                self.process_page(child_url, depth + 1, url, allowed_urls)
                
                # 处理完子页面后，确保返回父页面
                if parent_url:
                    print(f"返回父页面: {parent_url}")
                    self.driver.get(parent_url)
                    time.sleep(2)
            
        except Exception as e:
            print(f"处理页面时出错: {str(e)}")

    def start(self, url, allowed_urls=None):
        """开始处理页面"""
        try:
            print(f"\n开始处理页面: {url}")
            self.current_url = url  # 设置当前URL
            
            # 如果提供了允许的URL列表，确保起始URL在列表中
            if allowed_urls is not None:
                allowed_urls = set(allowed_urls)  # 转换为集合以提高查找效率
                if url not in allowed_urls:
                    allowed_urls.add(url)  # 添加起始URL
                print(f"指定遍历以下页面: {', '.join(allowed_urls)}")
            
            # 从第一个页面开始递归处理
            self.process_page(url, allowed_urls=allowed_urls)
            
        except Exception as e:
            print(f"处理页面时出错: {str(e)}")
        finally:
            try:
                self.save_results()  # 保存结果
                self.driver.quit()   # 关闭浏览器
            except:
                pass

    def get_clickable_elements(self):
        """获取页面上所有可点击的元素"""
        try:
            elements = []
            
            # 等待页面加载完成
            WebDriverWait(self.driver, 10).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            
            # 使用JavaScript获取所有可点击元素
            js_script = """
                function getClickableElements() {
                    let elements = [];
                    
                    // 定义要查找的选择器
                    const selectors = [
                        'button', 
                        'a[href]',
                        'input[type="button"]',
                        'input[type="submit"]',
                        '[role="button"]',
                        '[onclick]',
                        '.btn',
                        '[class*="button"]',
                        '[tabindex]',
                        '[data-click]',
                        '[ng-click]',
                        '[v-on:click]',
                        '[data-toggle]',
                        'div[class*="click"]',
                        'span[class*="click"]'
                    ];
                    
                    // 遍历每个选择器
                    for (let selector of selectors) {
                        try {
                            // 查找匹配的元素
                            let found = document.querySelectorAll(selector);
                            if (found && found.length > 0) {
                                for (let element of found) {
                                    // 检查元素是否可见
                                    let rect = element.getBoundingClientRect();
                                    let style = window.getComputedStyle(element);
                                    
                                    if (rect.width > 0 && 
                                        rect.height > 0 && 
                                        style.display !== 'none' && 
                                        style.visibility !== 'hidden' &&
                                        style.opacity !== '0') {
                                        
                                        elements.push({
                                            element: element,
                                            position: {
                                                top: rect.top + window.pageYOffset,
                                                left: rect.left + window.pageXOffset
                                            },
                                            info: {
                                                tag: element.tagName.toLowerCase(),
                                                text: element.textContent.trim(),
                                                id: element.id || '',
                                                class: element.className || ''
                                            }
                                        });
                                    }
                                }
                            }
                        } catch (error) {
                            console.error('Error processing selector:', selector, error);
                        }
                    }
                    
                    // 按照从上到下，从左到右排序
                    return elements.sort((a, b) => {
                        let yDiff = a.position.top - b.position.top;
                        return Math.abs(yDiff) < 30 ? 
                               a.position.left - b.position.left : 
                               yDiff;
                    });
                }
                return getClickableElements();
            """
            
            # 执行JavaScript获取元素
            elements_info = self.driver.execute_script(js_script)
            
            # 处理找到的元素
            if elements_info and isinstance(elements_info, list):
                for info in elements_info:
                    try:
                        element = info['element']
                        if self.is_element_clickable(element):
                            elements.append({
                                'element': element,
                                'info': {
                                    'type': info['info']['tag'],
                                    'text': info['info']['text'],
                                    'id': info['info']['id'],
                                    'class': info['info']['class'],
                                    'xpath': self.get_element_xpath(element)
                                },
                                'position': info['position']
                            })
                    except Exception as e:
                        print(f"处理元素时出错: {str(e)}")
                        continue
            
            # 打印找到的元素信息
            print(f"\n找到 {len(elements)} 个可点击元素:")
            for idx, elem in enumerate(elements, 1):
                info = elem['info']
                pos = elem['position']
                print(f"{idx}. {info['type']}: {info['text'][:50]}...")
                print(f"   位置: top={pos['top']:.0f}, left={pos['left']:.0f}")
            
            return elements
            
        except Exception as e:
            print(f"获取可点击元素时出错: {str(e)}")
            return []

    def is_element_clickable(self, element):
        """检查元素是否可点击"""
        try:
            # 基本检查
            if not element.is_displayed() or not element.is_enabled():
                return False
            
            # 获取元素大小和位置
            size = element.size
            location = element.location
            
            # 检查元素是否有有效大小
            if size['width'] < 5 or size['height'] < 5:
                return False
            
            # 检查元素是否在视口内
            viewport_script = """
                let rect = arguments[0].getBoundingClientRect();
                return {
                    inViewport: (
                        rect.top >= 0 &&
                        rect.left >= 0 &&
                        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                    ),
                    isVisible: window.getComputedStyle(arguments[0]).display !== 'none' &&
                              window.getComputedStyle(arguments[0]).visibility !== 'hidden'
                };
            """
            viewport_check = self.driver.execute_script(viewport_script, element)
            
            # 检查素是否被其他元素遮挡
            overlap_script = """
                let rect = arguments[0].getBoundingClientRect();
                let center = {
                    x: rect.left + rect.width / 2,
                    y: rect.top + rect.height / 2
                };
                let elementAtPoint = document.elementFromPoint(center.x, center.y);
                return elementAtPoint === arguments[0] || arguments[0].contains(elementAtPoint);
            """
            is_not_covered = self.driver.execute_script(overlap_script, element)
            
            return viewport_check['isVisible'] and is_not_covered
            
        except Exception as e:
            print(f"检查元素可点击性时出错: {str(e)}")
            return False
        
    def scroll_to_element(self, element):
        """滚动到元素位置"""
        try:
            # 首先检查元素是否仍然存在于DOM中
            if not self.verify_element_exists(element):
                print("元素不存在，跳过滚动")
                return False

            # 获取元素位置信息
            location = self.driver.execute_script("""
                var rect = arguments[0].getBoundingClientRect();
                return {
                    top: rect.top + window.pageYOffset,
                    left: rect.left + window.pageXOffset,
                    height: rect.height,
                    width: rect.width
                };
            """, element)

            # 计算滚动位置（使元素位于视口中央）
            viewport_height = self.driver.execute_script("return window.innerHeight;")
            scroll_to_y = location['top'] - (viewport_height / 2) + (location['height'] / 2)

            # 使用平滑滚动
            self.driver.execute_script("""
                window.scrollTo({
                    top: arguments[0],
                    behavior: 'smooth'
                });
            """, scroll_to_y)

            # 等待滚动完成
            time.sleep(1)

            # 验证元素��否在视口中
            is_visible = self.driver.execute_script("""
                var rect = arguments[0].getBoundingClientRect();
                return (
                    rect.top >= 0 &&
                    rect.left >= 0 &&
                    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                );
            """, element)

            if not is_visible:
                # 如果元素不在视口中，尝试直接滚动到元素
                self.driver.execute_script("""
                    arguments[0].scrollIntoView({
                        behavior: 'smooth',
                        block: 'center',
                        inline: 'center'
                    });
                """, element)
                time.sleep(1)

            return True

        except Exception as e:
            print(f"滚动到元素位置时出错: {str(e)}")
            return False

    def verify_element_exists(self, element):
        """验证元素是否存在且可交互"""
        try:
            # 检查元素是否仍然附加到DOM
            is_attached = self.driver.execute_script("""
                return (arguments[0].isConnected && 
                        arguments[0].offsetParent !== null &&
                        window.getComputedStyle(arguments[0]).display !== 'none' &&
                        window.getComputedStyle(arguments[0]).visibility !== 'hidden');
            """, element)

            if not is_attached:
                return False

            # 检查元素大小
            size = element.size
            if size['width'] < 1 or size['height'] < 1:
                return False

            # 检查元素是否可见且可交互
            return (element.is_displayed() and 
                    element.is_enabled() and 
                    self.is_element_in_viewport(element))

        except Exception as e:
            print(f"验证元素存在性时出错: {str(e)}")
            return False

    def is_element_in_viewport(self, element):
        """检查元素是否在视口中"""
        try:
            return self.driver.execute_script("""
                var rect = arguments[0].getBoundingClientRect();
                var windowHeight = (window.innerHeight || document.documentElement.clientHeight);
                var windowWidth = (window.innerWidth || document.documentElement.clientWidth);
                
                // 元素至少部分可见即可
                return (
                    rect.top < windowHeight &&
                    rect.bottom > 0 &&
                    rect.left < windowWidth &&
                    rect.right > 0
                );
            """, element)
        except Exception as e:
            print(f"检查元素是否在视口中时出错: {str(e)}")
            return False

    def click_element(self, element):
        """点击元素的多种尝试"""
        methods = [
            # 方法1：直接点击
            lambda: element.click(),
            
            # 方法2：JavaScript点击
            lambda: self.driver.execute_script("arguments[0].click();", element),
            
            # 方法3：ActionChains点击
            lambda: ActionChains(self.driver).move_to_element(element).click().perform(),
            
            # 方法4：JavaScript模拟鼠标事件
            lambda: self.driver.execute_script("""
                var evt = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                });
                arguments[0].dispatchEvent(evt);
            """, element)
        ]
        
        for method in methods:
            try:
                method()
                return True
            except:
                continue
                
        return False
        
    def get_element_xpath(self, element):
        """获取元素的XPath路径"""
        try:
            # 使用JavaScript获取XPath
            script = """
                function getElementXPath(element) {
                    if (!(element instanceof Element)) return '';
                    
                    // 如果元素有id，直接返回
                    if (element.id) {
                        return `//*[@id="${element.id}"]`;
                    }
                    
                    // 获取元素的完整路径
                    let path = [];
                    while (element && element.nodeType === Node.ELEMENT_NODE) {
                        let selector = element.nodeName.toLowerCase();
                        
                        // 如果元素有兄弟节点，添加索引
                        if (element.parentNode) {
                            let siblings = Array.from(element.parentNode.children).filter(
                                e => e.nodeName === element.nodeName
                            );
                            
                            if (siblings.length > 1) {
                                let index = siblings.indexOf(element) + 1;
                                selector += `[${index}]`;
                            }
                        }
                        
                        path.unshift(selector);
                        element = element.parentNode;
                    }
                    
                    return '/' + path.join('/');
                }
                return getElementXPath(arguments[0]);
            """
            
            xpath = self.driver.execute_script(script, element)
            return xpath
            
        except Exception as e:
            # 如果JavaScript方法失败，尝试使用备用方法
            try:
                # 使用id
                if element.get_attribute('id'):
                    return f"//*[@id='{element.get_attribute('id')}']"
                    
                # 使用class
                if element.get_attribute('class'):
                    classes = element.get_attribute('class').split()
                    if classes:
                        return f"//*[contains(@class, '{classes[0]}')]"
                    
                # 使用标签名和文本内容
                tag_name = element.tag_name
                text = element.text.strip() if element.text else ''
                if text:
                    return f"//{tag_name}[contains(text(), '{text}')]"
                    
                # 使用标签名和位置
                siblings = element.find_elements(By.XPATH, f"../{tag_name}")
                if siblings:
                    index = siblings.index(element) + 1
                    return f"(//{tag_name})[{index}]"
                    
                # 最后使用完整路径
                path = []
                current = element
                while current:
                    try:
                        parent = current.find_element(By.XPATH, "..")
                        siblings = parent.find_elements(By.XPATH, f"./{current.tag_name}")
                        index = siblings.index(current) + 1
                        path.insert(0, f"{current.tag_name}[{index}]")
                        current = parent
                    except:
                        break
                    
                return "/" + "/".join(path)
                
            except Exception as backup_error:
                self.logger.error(f"获取元素XPath时出错: {str(backup_error)}")
                return ""

    def get_element_xpath_with_attributes(self, element):
        """获取带有属性的XPath路径"""
        try:
            # 获取元素的重要属性
            attributes = {
                'id': element.get_attribute('id'),
                'class': element.get_attribute('class'),
                'name': element.get_attribute('name'),
                'type': element.get_attribute('type'),
                'value': element.get_attribute('value'),
                'href': element.get_attribute('href')
            }
            
            # 构建XPath
            xpath_parts = []
            
            # 添加有效的属性条件
            for attr, value in attributes.items():
                if value:
                    if attr == 'class':
                        # 处理多个类名
                        classes = value.split()
                        for class_name in classes:
                            xpath_parts.append(f"contains(@class, '{class_name}')")
                    else:
                        xpath_parts.append(f"@{attr}='{value}'")
                    
            if xpath_parts:
                return f"//*[{' and '.join(xpath_parts)}]"
            else:
                return self.get_element_xpath(element)
                
        except Exception as e:
            self.logger.error(f"获取带属性的XPath时出错: {str(e)}")
            return self.get_element_xpath(element)

    def verify_xpath(self, xpath):
        """验证XPath是否有效"""
        try:
            elements = self.driver.find_elements(By.XPATH, xpath)
            return len(elements) > 0
        except:
            return False
        
    def highlight_element(self, element):
        """高亮显示当前操作的元素"""
        try:
            # 首先检查元素是否仍然存在于DOM中
            try:
                self.driver.execute_script("return arguments[0].nodeType;", element)
            except:
                print("元素已失效，尝试重新定位...")
                return False
            
            # 使用JavaScript高亮元素，避免直接操作元素
            highlight_script = """
                function highlightElement(element) {
                    try {
                        // 保存原始样式
                        const originalStyle = {
                            border: element.style.border,
                            backgroundColor: element.style.backgroundColor,
                            boxShadow: element.style.boxShadow,
                            transition: element.style.transition
                        };
                        
                        // 添加高亮样式
                        element.style.border = '3px solid red';
                        element.style.backgroundColor = 'yellow';
                        element.style.boxShadow = '0 0 10px rgba(255, 0, 0, 0.5)';
                        element.style.transition = 'all 0.3s';
                        
                        // 1秒后恢复原始样式
                        setTimeout(() => {
                            element.style.border = originalStyle.border;
                            element.style.backgroundColor = originalStyle.backgroundColor;
                            element.style.boxShadow = originalStyle.boxShadow;
                            element.style.transition = originalStyle.transition;
                        }, 1000);
                        
                        return true;
                    } catch (error) {
                        console.error('高亮元素时出错:', error);
                        return false;
                    }
                }
                return highlightElement(arguments[0]);
            """
            
            # 执行高亮脚本
            result = self.driver.execute_script(highlight_script, element)
            
            if result:
                time.sleep(1)  # 等待高亮效果显示
                return True
            else:
                print("高亮元素失败")
                return False
                
        except Exception as e:
            print(f"高亮元素时出错: {str(e)}")
            return False

    def safe_highlight_element(self, element):
        """安全地高亮显示元素，包含重试机制"""
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                # 确保元素在视图中
                self.driver.execute_script(
                    "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});",
                    element
                )
                time.sleep(0.5)  # 等待滚动完成
                
                # 检查元素是否仍然有效
                if not self.is_element_valid(element):
                    print(f"元素无效，重试 {retry_count + 1}/{max_retries}")
                    retry_count += 1
                    continue
                
                # 尝试高亮显示
                if self.highlight_element(element):
                    return True
                    
                retry_count += 1
                time.sleep(0.5)
                
            except Exception as e:
                print(f"高亮尝试失败 ({retry_count + 1}/{max_retries}): {str(e)}")
                retry_count += 1
                time.sleep(0.5)
                
        return False

    def is_element_valid(self, element):
        """检查元素是否仍���有效"""
        try:
            # 检查元素是否仍在DOM中
            self.driver.execute_script("return arguments[0].nodeType;", element)
            
            # 检查元素是否可见
            return (element.is_displayed() and 
                    element.is_enabled() and 
                    element.size['height'] > 0 and 
                    element.size['width'] > 0)
        except:
            return False

    def scroll_to_element_with_highlight(self, element):
        """滚动到元素位置并高亮显示"""
        try:
            # 滚动到元素位置
            scroll_script = """
                arguments[0].scrollIntoView({
                    behavior: 'smooth',
                    block: 'center',
                    inline: 'center'
                });
            """
            self.driver.execute_script(scroll_script, element)
            
            # 等待滚动完成
            time.sleep(0.5)
            
            # 高亮显示元素
            self.highlight_element(element)
            
            return True
        except Exception as e:
            print(f"滚动并高亮元素时出错: {str(e)}")
            return False

    def flash_element(self, element, color='red', duration=1):
        """闪烁显示元素"""
        try:
            flash_script = f"""
                (function() {{
                    const element = arguments[0];
                    const originalBackground = element.style.backgroundColor;
                    const originalTransition = element.style.transition;
                    
                    element.style.transition = 'background-color 0.3s';
                    element.style.backgroundColor = '{color}';
                    
                    setTimeout(() => {{
                        element.style.backgroundColor = originalBackground;
                        element.style.transition = originalTransition;
                    }}, {duration * 1000});
                }})();
            """
            self.driver.execute_script(flash_script, element)
            time.sleep(duration)
        except Exception as e:
            print(f"闪烁显示元素时出错: {str(e)}")
        
    def take_screenshot(self, prefix):
        """保存截图并返回路径"""
        try:
            # 创建截图目录（如果不存在）
            if not os.path.exists(self.screenshots_dir):
                os.makedirs(self.screenshots_dir)
            
            # 生成文件名
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{prefix}_{timestamp}.png"
            filepath = os.path.join(self.screenshots_dir, filename)
            
            # 保存截图
            self.driver.save_screenshot(filepath)
            
            # 使用PIL优化图片大小
            with PILImage.open(filepath) as img:
                # 调整图片大小
                max_size = (800, 600)
                img.thumbnail(max_size, PILImage.Resampling.LANCZOS)
                
                # 保存优化后的图片
                img.save(filepath, optimize=True, quality=85)
            
            print(f"截图已保存: {filepath}")
            return filepath
            
        except Exception as e:
            print(f"截图失败: {str(e)}")
            return ''

    def write_to_excel(self, row_data):
        """写入数据到Excel，包括截图"""
        try:
            row = len(list(self.sheet.rows)) + 1
            
            # 写入基本数据
            self.sheet.cell(row=row, column=1, value=row_data['index'])
            self.sheet.cell(row=row, column=2, value=row_data['type'])
            self.sheet.cell(row=row, column=3, value=row_data['text'])
            self.sheet.cell(row=row, column=4, value=row_data['position'])
            self.sheet.cell(row=row, column=5, value=row_data['status'])
            self.sheet.cell(row=row, column=6, value=row_data['error'])
            
            # 处理截图
            if row_data['screenshot']:
                try:
                    # 调整行高以适应图片
                    self.sheet.row_dimensions[row].height = 150
                    
                    # 调整列宽
                    self.sheet.column_dimensions['G'].width = 50
                    
                    # 读取并调整图片大小
                    img = Image(row_data['screenshot'])
                    
                    # 设置图片大小（保持纵横比）
                    max_width = 300
                    max_height = 200
                    ratio = min(max_width/img.width, max_height/img.height)
                    img.width = img.width * ratio
                    img.height = img.height * ratio
                    
                    # 将图片添加到单元格
                    cell = self.sheet.cell(row=row, column=7)
                    img.anchor = cell.coordinate
                    self.sheet.add_image(img)
                    
                    # 同时记录图片路径
                    self.sheet.cell(row=row, column=7, value=row_data['screenshot'])
                    
                except Exception as img_error:
                    print(f"添加图片到Excel时出错: {str(img_error)}")
                    # 如果添加图片失败，至少保存路径
                    self.sheet.cell(row=row, column=7, value=row_data['screenshot'])
            
        except Exception as e:
            print(f"写入Excel失败: {str(e)}")

    def save_results(self):
        """保存结果到Excel"""
        try:
            # 设置打印区域
            self.sheet.print_area = self.sheet.dimensions
            
            # 设置适应打印的格式
            self.sheet.page_setup.fitToWidth = 1
            self.sheet.page_setup.fitToHeight = False
            
            # 保存文件
            result_file = os.path.join(self.result_dir, 'result.xlsx')
            self.workbook.save(result_file)
            print(f"\n结果已保存到: {result_file}")
            
            # 尝试自动打开文件
            try:
                os.startfile(result_file)
            except:
                pass
            
        except Exception as e:
            print(f"保存结果失败: {str(e)}")

    def handle_navigation_changes(self):
        """处理导航变化"""
        try:
            time.sleep(1)
            
            # 处理新窗口
            new_handles = [h for h in self.driver.window_handles if h != self.driver.current_window_handle]
            if new_handles:
                for handle in new_handles:
                    self.driver.switch_to.window(handle)
                    print(f"处理新窗口: {self.driver.current_url}")
                    self.driver.close()
                self.driver.switch_to.window(self.driver.window_handles[0])
            
            # 检查URL变化
            current_url = self.driver.current_url
            if current_url != self.current_url:  # 使用实例性
                print(f"检测到页面变化，从 {self.current_url} 变为 {current_url}")
                print("返回原页面")
                self.driver.back()
                time.sleep(1)
                # 确保回到原始页面
                if self.driver.current_url != self.current_url:
                    print("尝试再次返回原页面")
                    self.driver.get(self.current_url)
                    time.sleep(1)
                
        except Exception as e:
            print(f"处理导航变化时出错: {str(e)}")
        
    def check_login_required(self):
        """检查页面是否需要登录"""
        try:
            # 检查常见的登录相关元素和文本
            login_indicators = [
                # 文本内容检查
                "//button[contains(text(), '登录') or contains(text(), 'Login')]",
                "//a[contains(text(), '登录') or contains(text(), 'Login')]",
                "//input[@type='password']",
                "//form[contains(@action, 'login')]",
                
                # 类名和ID检查
                "//*[contains(@class, 'login')]",
                "//*[contains(@id, 'login')]",
                "//*[contains(@class, 'sign-in')]",
                "//*[contains(@id, 'sign-in')]",
                
                # URL检查
                "//form[contains(@action, 'signin')]",
                
                # 其他常见登录元素
                "//input[@name='username']",
                "//input[@name='password']",
                "//input[@type='password']",
                
                # 登录相关文本
                "//*[contains(text(), '用户名')]",
                "//*[contains(text(), '密码')]",
                "//*[contains(text(), 'Username')]",
                "//*[contains(text(), 'Password')]"
            ]
            
            # 检查登录元素
            for indicator in login_indicators:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements and any(element.is_displayed() for element in elements):
                    return True
                
            # 检查URL中的关键词
            current_url = self.driver.current_url.lower()
            url_keywords = ['login', 'signin', 'logon', 'auth', 'sign-in', 'signon']
            if any(keyword in current_url for keyword in url_keywords):
                return True
            
            # 检查登录成功后常见的元素（如果存在这些元素，说明已经登录）
            logged_in_indicators = [
                "//a[contains(text(), '退出') or contains(text(), 'Logout')]",
                "//button[contains(text(), '退出') or contains(text(), 'Logout')]",
                "//*[contains(@class, 'logout')]",
                "//*[contains(@id, 'logout')]",
                "//a[contains(text(), '个人中心')]",
                "//a[contains(text(), 'Profile')]",
                "//*[contains(@class, 'user-info')]"
            ]
            
            # 如果找到任何已登录的标志，返回False表示不需要登录
            for indicator in logged_in_indicators:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements and any(element.is_displayed() for element in elements):
                    return False
            
            return False
            
        except Exception as e:
            print(f"检查登录状态时出错: {str(e)}")
            return False
        
    def wait_for_login(self, timeout=300):
        """等待用户完成登录操作"""
        try:
            start_time = time.time()
            print(f"\n请在 {timeout} 秒内完成登录操作...")
            
            while time.time() - start_time < timeout:
                # 检查是否仍在登录页面
                if not self.check_login_required():
                    print("\n检测到登录成功！")
                    return True  # 登录成功立即返回，不再等待
                
                # 每2秒检查一次
                time.sleep(2)
                remaining = int(timeout - (time.time() - start_time))
                print(f"\r剩余等待时间: {remaining} 秒...", end='')
            
            print("\n登录等待超时！")
            return False
            
        except Exception as e:
            print(f"等待登录时出错: {str(e)}")
            return False
        