from flask import Flask, render_template, request, jsonify
from crawler.main import WebCrawler
import threading
import queue
import os

app = Flask(__name__)

# 用于存储爬虫实例和状态
crawler_status = {
    'is_running': False,
    'current_url': None,
    'log_queue': queue.Queue(),
    'crawler_instance': None
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_crawler', methods=['POST'])
def start_crawler():
    if crawler_status['is_running']:
        return jsonify({'status': 'error', 'message': '爬虫已在运行中'})
    
    url = request.json.get('url')
    if not url:
        return jsonify({'status': 'error', 'message': '请输入URL'})
    
    try:
        # 启动爬虫线程
        crawler_thread = threading.Thread(target=run_crawler, args=(url,))
        crawler_thread.daemon = True
        crawler_thread.start()
        
        return jsonify({'status': 'success', 'message': '爬虫已启动'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/stop_crawler', methods=['POST'])
def stop_crawler():
    if not crawler_status['is_running']:
        return jsonify({'status': 'error', 'message': '爬虫未运行'})
    
    try:
        if crawler_status['crawler_instance']:
            crawler_status['crawler_instance'].stop()
        crawler_status['is_running'] = False
        return jsonify({'status': 'success', 'message': '爬虫已停止'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/get_logs')
def get_logs():
    logs = []
    while not crawler_status['log_queue'].empty():
        logs.append(crawler_status['log_queue'].get())
    return jsonify({'logs': logs})

def run_crawler(url):
    try:
        crawler_status['is_running'] = True
        crawler_status['current_url'] = url
        crawler_status['log_queue'].put(f"开始爬取: {url}")
        
        config_path = os.path.join(os.path.dirname(__file__), 'config', 'crawler_config.yml')
        
        # 创建爬虫实例
        try:
            crawler = WebCrawler(config_path, use_proxy=False)
            crawler_status['crawler_instance'] = crawler
            
            # 重写日志输出方法
            def log_message(message):
                crawler_status['log_queue'].put(message)
            
            crawler.log_message = log_message
            
            # 运行爬虫
            crawler.run(url)
            
        except Exception as crawler_error:
            error_message = f"爬虫初始化失败: {str(crawler_error)}"
            crawler_status['log_queue'].put(error_message)
            raise
            
    except Exception as e:
        error_message = f"爬虫运行出错: {str(e)}"
        crawler_status['log_queue'].put(error_message)
    finally:
        if crawler_status.get('crawler_instance'):
            try:
                crawler_status['crawler_instance'].driver.quit()
            except:
                pass
        crawler_status['is_running'] = False
        crawler_status['current_url'] = None
        crawler_status['crawler_instance'] = None
        crawler_status['log_queue'].put("爬虫已停止")

if __name__ == '__main__':
    app.run(debug=True, port=5000) 