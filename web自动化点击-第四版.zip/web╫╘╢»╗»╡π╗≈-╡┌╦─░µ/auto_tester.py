from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from openpyxl import load_workbook, Workbook
import time
import os
from datetime import datetime

class AutoTester:
    def __init__(self, elements_file, result_file):
        self.options = webdriver.ChromeOptions()
        self.options.add_argument('--start-maximized')
        self.driver = webdriver.Chrome(options=self.options)
        self.elements_wb = load_workbook(elements_file)
        self.elements_sheet = self.elements_wb.active
        self.result_wb = Workbook()
        self.result_sheet = self.result_wb.active
        self.setup_result_excel()
        self.result_file = result_file
        self.current_window = None
        
    def setup_result_excel(self):
        """设置结果Excel表头"""
        headers = [
            '时间', '页面URL', '元素描述', '操作结果', 
            '错误信息', '截图路径', '窗口句柄'
        ]
        for col, header in enumerate(headers, 1):
            self.result_sheet.cell(row=1, column=col, value=header)
            
    def create_screenshot_dir(self):
        """创建截图目录"""
        if not os.path.exists('screenshots'):
            os.makedirs('screenshots')
            
    def take_screenshot(self, element_desc):
        """捕获截图"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'screenshots/element_{timestamp}.png'
        self.driver.save_screenshot(filename)
        return filename
        
    def login_if_needed(self, username, password):
        """检查并执行登录"""
        login_indicators = [
            "//input[@type='password']",
            "//button[contains(text(), '登录')]",
            "//a[contains(text(), '登录')]"
        ]
        
        for indicator in login_indicators:
            try:
                if self.driver.find_elements(By.XPATH, indicator):
                    print("检测到登录页面，执行登录...")
                    # 查找用户名输入框
                    username_field = self.driver.find_element(By.XPATH, "//input[@type='text']")
                    username_field.send_keys(username)
                    
                    # 查找密码输入框
                    password_field = self.driver.find_element(By.XPATH, "//input[@type='password']")
                    password_field.send_keys(password)
                    
                    # 点击登录按钮
                    login_button = self.driver.find_element(By.XPATH, "//button[contains(text(), '登录')]")
                    login_button.click()
                    
                    # 等待登录完成
                    time.sleep(5)
                    return True
            except:
                continue
        return False
        
    def execute_tests(self, username='', password=''):
        """执行自动化测试"""
        row = 2
        result_row = 2
        current_url = None
        
        while row <= self.elements_sheet.max_row:
            try:
                # 读取元素信息
                url = self.elements_sheet.cell(row=row, column=2).value
                element_type = self.elements_sheet.cell(row=row, column=3).value
                element_text = self.elements_sheet.cell(row=row, column=4).value
                xpath = self.elements_sheet.cell(row=row, column=5).value
                hierarchy = self.elements_sheet.cell(row=row, column=6).value
                
                # 如果是新页面，先导航到该页面
                if url != current_url:
                    self.driver.get(url)
                    current_url = url
                    time.sleep(3)
                    
                    # 检查是否需要登录
                    if self.login_if_needed(username, password):
                        time.sleep(3)
                    
                # 尝试查找并点击元素
                try:
                    element = WebDriverWait(self.driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, xpath))
                    )
                    
                    # 滚动元素到可见位置
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
                    time.sleep(1)
                    
                    # 高亮显示当前操作的元素
                    self.highlight_element(element)
                    
                    # 记录当前窗口句柄
                    current_handle = self.driver.current_window_handle
                    
                    # 点击元素
                    element.click()
                    time.sleep(2)
                    
                    # 处理新窗口
                    self.handle_new_window(current_handle)
                    
                    # 记录成功结果
                    self.record_result(
                        result_row,
                        url,
                        f"{element_type}: {element_text}",
                        "成功",
                        "",
                        self.take_screenshot(element_text),
                        self.driver.current_window_handle
                    )
                    
                except Exception as e:
                    # 记录失败结果
                    self.record_result(
                        result_row,
                        url,
                        f"{element_type}: {element_text}",
                        "失败",
                        str(e),
                        self.take_screenshot(element_text),
                        self.driver.current_window_handle if self.driver.current_window_handle else "N/A"
                    )
                    
                result_row += 1
                row += 1
                
            except Exception as e:
                print(f"处理行 {row} 时出错: {str(e)}")
                row += 1
                continue
                
        # 保存结果
        self.result_wb.save(self.result_file)
        
    def highlight_element(self, element):
        """高亮显示当前操作的元素"""
        original_style = element.get_attribute('style')
        self.driver.execute_script(
            "arguments[0].setAttribute('style', arguments[1]);",
            element,
            "border: 2px solid red; background: yellow;"
        )
        time.sleep(1)
        self.driver.execute_script(
            "arguments[0].setAttribute('style', arguments[1]);",
            element,
            original_style
        )
        
    def handle_new_window(self, original_handle):
        """处理新窗口"""
        handles = self.driver.window_handles
        if len(handles) > 1:
            for handle in handles:
                if handle != original_handle:
                    self.driver.switch_to.window(handle)
                    time.sleep(2)
                    self.driver.close()
            self.driver.switch_to.window(original_handle)
            
    def record_result(self, row, url, element_desc, result, error, screenshot, handle):
        """记录测试结果"""
        self.result_sheet.cell(row=row, column=1, value=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        self.result_sheet.cell(row=row, column=2, value=url)
        self.result_sheet.cell(row=row, column=3, value=element_desc)
        self.result_sheet.cell(row=row, column=4, value=result)
        self.result_sheet.cell(row=row, column=5, value=error)
        self.result_sheet.cell(row=row, column=6, value=screenshot)
        self.result_sheet.cell(row=row, column=7, value=str(handle))
        
    def close(self):
        """关闭浏览器和Excel文件"""
        self.driver.quit()
        self.elements_wb.close()
        self.result_wb.close() 