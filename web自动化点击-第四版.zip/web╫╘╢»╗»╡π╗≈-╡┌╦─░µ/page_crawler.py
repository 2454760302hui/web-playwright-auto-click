from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from openpyxl import Workbook
import time
import os
from datetime import datetime

class PageElementCrawler:
    def __init__(self):
        try:
            print("正在启动Chrome浏览器...")
            # 配置Chrome选项
            self.options = webdriver.ChromeOptions()
            self.options.add_argument('--start-maximized')
            self.options.add_argument('--no-sandbox')
            self.options.add_argument('--disable-dev-shm-usage')
            self.options.add_argument('--disable-gpu')
            self.options.add_experimental_option('excludeSwitches', ['enable-automation'])
            self.options.add_experimental_option('useAutomationExtension', False)
            
            # 使用 Service 类来启动 Chrome，添加详细的错误处理
            from selenium.webdriver.chrome.service import Service
            from selenium.common.exceptions import WebDriverException
            
            try:
                # 尝试使用默认路径
                service = Service()
                self.driver = None  # 初始化为 None
                
                try:
                    self.driver = webdriver.Chrome(service=service, options=self.options)
                    print("Chrome浏览器启动成功（使用默认配置）")
                except WebDriverException as e:
                    print(f"使用默认配置启动失败: {str(e)}")
                    
                    # 尝试查找 Chrome 安装路径
                    chrome_paths = [
                        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                        os.path.expanduser("~") + r"\AppData\Local\Google\Chrome\Application\chrome.exe"
                    ]
                    
                    for chrome_path in chrome_paths:
                        if os.path.exists(chrome_path):
                            print(f"找到Chrome浏览器: {chrome_path}")
                            self.options.binary_location = chrome_path
                            try:
                                self.driver = webdriver.Chrome(options=self.options)
                                print(f"使用指定路径启动成功: {chrome_path}")
                                break
                            except Exception as path_error:
                                print(f"使用路径 {chrome_path} 启动失败: {str(path_error)}")
                                continue
                    
                    if not self.driver:
                        raise Exception("未能找到可用的Chrome浏览器")
                
                # 设置隐式等待时间
                self.driver.implicitly_wait(10)
                
                # 初始化其他组件
                self.workbook = Workbook()
                self.sheet = self.workbook.active
                self.setup_excel()
                
            except Exception as browser_error:
                error_msg = f"Chrome浏览器启动失败: {str(browser_error)}"
                print(error_msg)
                if self.driver:
                    try:
                        self.driver.quit()
                    except:
                        pass
                raise Exception(error_msg)
                
        except Exception as init_error:
            print(f"初始化失败: {str(init_error)}")
            # 确保资源被清理
            if hasattr(self, 'driver') and self.driver:
                try:
                    self.driver.quit()
                except:
                    pass
            raise
        
    def setup_excel(self):
        """设置Excel表头"""
        headers = [
            '元素ID', '页面URL', '元素类型', '元素文本', 'XPath',
            '层级', '位置信息', '可点击', '父元素'
        ]
        for col, header in enumerate(headers, 1):
            self.sheet.cell(row=1, column=col, value=header)
            
    def get_element_position(self, element):
        """获取元素在页面中的位置"""
        location = element.location
        size = element.size
        return {
            'x': location['x'],
            'y': location['y'],
            'width': size['width'],
            'height': size['height']
        }
        
    def get_element_hierarchy(self, element):
        """获取元素的层级信息"""
        script = """
            let element = arguments[0];
            let hierarchy = [];
            while (element && element.tagName !== 'HTML') {
                let tag = element.tagName.toLowerCase();
                let id = element.id ? '#' + element.id : '';
                let classes = Array.from(element.classList).map(c => '.' + c).join('');
                hierarchy.unshift(tag + id + classes);
                element = element.parentElement;
            }
            return hierarchy.join(' > ');
        """
        return self.driver.execute_script(script, element)
        
    def crawl_page(self, url):
        """爬取页面元素"""
        try:
            self.driver.get(url)
            time.sleep(3)  # 等待页面加载
            
            # 滚动页面以加载所有元素
            self.scroll_page()
            
            # 获取所有可交互元素
            elements = self.driver.find_elements(By.CSS_SELECTOR, 
                "button, a, input, select, [role='button'], [onclick], .btn, [class*='button']")
            
            row = 2  # Excel起始行
            for element in elements:
                try:
                    # 获取元素信息
                    element_info = {
                        'id': element.get_attribute('id') or '',
                        'type': element.tag_name,
                        'text': element.text or element.get_attribute('value') or '',
                        'xpath': self.get_xpath(element),
                        'hierarchy': self.get_element_hierarchy(element),
                        'position': self.get_element_position(element),
                        'clickable': element.is_enabled() and element.is_displayed(),
                        'parent': self.get_parent_info(element)
                    }
                    
                    # 写入Excel
                    self.sheet.cell(row=row, column=1, value=element_info['id'])
                    self.sheet.cell(row=row, column=2, value=url)
                    self.sheet.cell(row=row, column=3, value=element_info['type'])
                    self.sheet.cell(row=row, column=4, value=element_info['text'])
                    self.sheet.cell(row=row, column=5, value=element_info['xpath'])
                    self.sheet.cell(row=row, column=6, value=element_info['hierarchy'])
                    self.sheet.cell(row=row, column=7, value=str(element_info['position']))
                    self.sheet.cell(row=row, column=8, value=str(element_info['clickable']))
                    self.sheet.cell(row=row, column=9, value=element_info['parent'])
                    
                    row += 1
                    
                except Exception as e:
                    print(f"处理元素时出错: {str(e)}")
                    continue
                    
        except Exception as e:
            print(f"爬取页面出错: {str(e)}")
            
    def scroll_page(self):
        """滚动页面以加载所有内容"""
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        while True:
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height
            
    def get_xpath(self, element):
        """获取元素的XPath"""
        script = """
            function getXPath(element) {
                if (element.id !== '')
                    return `//*[@id="${element.id}"]`;
                if (element === document.body)
                    return '/html/body';
                    
                let path = '';
                while (element !== document.body) {
                    let tag = element.tagName.toLowerCase();
                    let siblings = Array.from(element.parentNode.children)
                        .filter(e => e.tagName === element.tagName);
                    let index = siblings.indexOf(element) + 1;
                    path = `/${tag}[${index}]${path}`;
                    element = element.parentNode;
                }
                return `/html/body${path}`;
            }
            return getXPath(arguments[0]);
        """
        return self.driver.execute_script(script, element)
        
    def get_parent_info(self, element):
        """获取父元素信息"""
        script = """
            let parent = arguments[0].parentElement;
            if (!parent) return '';
            return {
                tag: parent.tagName.toLowerCase(),
                id: parent.id,
                class: parent.className
            };
        """
        return str(self.driver.execute_script(script, element))
        
    def save_to_excel(self, filename='page_elements.xlsx'):
        """保存结果到Excel"""
        self.workbook.save(filename)
        
    def close(self):
        """关闭浏览器"""
        self.driver.quit() 